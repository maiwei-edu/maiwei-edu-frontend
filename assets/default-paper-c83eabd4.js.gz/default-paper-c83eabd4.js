const p="/assets/default-paper-5f61a797.png";export{p};
