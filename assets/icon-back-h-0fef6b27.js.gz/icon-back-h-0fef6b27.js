const a="/assets/icon-back-h-ea72d829.png";export{a as b};
